package com.self.atlas.twitter.adapter.dao;

import org.springframework.data.repository.CrudRepository;

import com.self.atlas.twitter.adapter.entity.TweetRepAnalyticsEntity;

public interface TweetReplyAnalyticsRepository extends CrudRepository<TweetRepAnalyticsEntity, Long>{

}
