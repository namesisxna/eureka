package com.self.atlas.twitter.adapter.routes;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.rest.RestParamType;
import org.springframework.social.twitter.api.Tweet;
import org.springframework.stereotype.Component;
@Component
public class TwitterAdapterSearchInterfaceRoute extends RouteBuilder{

	@Override
	public void configure() throws Exception {
		rest()
		.get("/search/user/{userScreenName}/tweet/{statusId}/repTweets")
		 .id("getRepTweets")
         .description("endpoint to search all reply of a tweet send to a particular user ")
         		.param()
         			.name("enable_analytics")
         			.type(RestParamType.query)
         			.description("to enable analytics")
         		.endParam()
        		.param()
        			.name("pageSize")
        			.type(RestParamType.query)
        			.description("no of rep tweets to be search default 10")
        		.endParam()
         .outType(Tweet[].class)
         .to("direct:getUserRepTweets");
		
	}

}
