package com.self.atlas.twitter.adapter.analytics;

import java.util.Map;



import org.apache.camel.Exchange;
import org.apache.camel.ProducerTemplate;
import org.apache.http.client.HttpClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;



import com.fasterxml.jackson.databind.JsonNode;
import com.self.atlas.twitter.adapter.dao.TweetReplyAnalyticsRepository;
import com.self.atlas.twitter.adapter.dao.TweeterReplyRepository;
import com.self.atlas.twitter.adapter.dao.TweeterRepository;
import com.self.atlas.twitter.adapter.entity.TweetEntity;
import com.self.atlas.twitter.adapter.entity.TweetRepAnalyticsEntity;
import com.self.atlas.twitter.adapter.entity.TweetRepEntity;
import com.self.atlas.twitter.adapter.utils.HttpClientUtils;

@Component
public class TweeterAnalyticsService {
	@Autowired
	private TweeterRepository tweeterRepository;
	@Autowired
	private TweeterReplyRepository tweeterReplyRepository;
	
	@Autowired
	private TweetReplyAnalyticsRepository tweetReplyAnalyticsRepository;
	@Autowired
	public HttpClientUtils client;
	
	public void buildInReplyAnalysis(Exchange exchange){
		Map<String, Object> headers = exchange.getIn().getHeaders();
		tweeterRepository.findAll().forEach(tweetEntity-> {
			String fromUser = tweetEntity.getFromUser();
			long status_id = tweetEntity.getStatus_id();
			headers.put("userScreenName", fromUser);
			headers.put("statusId", status_id);
			headers.put("enable_analytics", true);
			System.out.println(headers.get("userScreenName"));
			ProducerTemplate template = exchange.getContext().createProducerTemplate();
			template.sendBodyAndHeaders("direct:getUserRepTweets", null, headers);
			Iterable<TweetRepEntity> tweetRepEntities = tweeterReplyRepository.findAll();
			tweetRepEntities.forEach((tweetRepEntity)->{
				String text = tweetRepEntity.getText();
				JsonNode httpPost = client.httpPost("http://127.0.0.1:8000/createEmotionScore", text);
				TweetRepAnalyticsEntity tweetRepAnalyticsEntity  = new TweetRepAnalyticsEntity();
				httpPost.forEach((result)->{
					tweetRepAnalyticsEntity.setStatus_id(tweetRepEntity.getStatus_id());
					tweetRepAnalyticsEntity.setAnger(Double.valueOf(result.get("anger").toString()));
					tweetRepAnalyticsEntity.setAnticipation(Double.valueOf(result.get("anticipation").toString()));
					tweetRepAnalyticsEntity.setDisgust(Double.valueOf(result.get("disgust").toString()));
					tweetRepAnalyticsEntity.setFear(Double.valueOf(result.get("fear").toString()));
					tweetRepAnalyticsEntity.setJoy(Double.valueOf(result.get("joy").toString()));
					tweetRepAnalyticsEntity.setSadness(Double.valueOf(result.get("sadness").toString()));
					tweetRepAnalyticsEntity.setSurprise(Double.valueOf(result.get("surprise").toString()));
					tweetRepAnalyticsEntity.setTrust(Double.valueOf(result.get("trust").toString()));
					tweetRepAnalyticsEntity.setPositive(Double.valueOf(result.get("positive").toString()));
					tweetRepAnalyticsEntity.setNegative(Double.valueOf(result.get("negative").toString()));
					
				});
				tweetReplyAnalyticsRepository.save(tweetRepAnalyticsEntity);
				
			});
			//getReplyTweet
			
		});
		
		
	}

}
