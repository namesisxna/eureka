package com.self.atlas.twitter.adapter.routes.impl;

import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

import com.self.atlas.twitter.adapter.service.TweeterAdapterSearchService;
import com.self.atlas.twitter.adapter.service.TweeterAdapterTimelineService;
@Component
public class TwitterAdapterSearchImplementationRoute extends RouteBuilder{

	@Override
	public void configure() throws Exception {
		// TODO Auto-generated method stub
		
		from("direct:getUserRepTweets")
			.id("getUserRepTweetsImplRoute")
			.log("Entering getUserRepTweetsImplRoute")
			.bean(TweeterAdapterSearchService.class,"getReplyTweet")
			.setHeader(Exchange.HTTP_RESPONSE_CODE,constant(200))
			.log("Exiting getUserRepTweetsImplRoute");
		
	}

}
