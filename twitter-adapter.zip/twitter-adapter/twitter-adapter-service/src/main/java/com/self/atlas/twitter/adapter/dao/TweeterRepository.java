package com.self.atlas.twitter.adapter.dao;

import org.springframework.data.repository.CrudRepository;

import com.self.atlas.twitter.adapter.entity.TweetEntity;

public interface TweeterRepository extends CrudRepository<TweetEntity, Long>{

}
