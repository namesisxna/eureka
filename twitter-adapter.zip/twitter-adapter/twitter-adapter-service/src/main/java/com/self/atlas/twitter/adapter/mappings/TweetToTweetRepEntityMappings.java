package com.self.atlas.twitter.adapter.mappings;

import org.modelmapper.PropertyMap;
import org.springframework.social.twitter.api.Tweet;
import org.springframework.stereotype.Component;

import com.self.atlas.twitter.adapter.entity.TweetRepEntity;

public class TweetToTweetRepEntityMappings extends PropertyMap<Tweet, TweetRepEntity>{

	@Override
	protected void configure() {
		// TODO Auto-generated method stub
		map(source.getId(), destination.status_id);
	    map(source.getText(), destination.text);
	    map(source.getCreatedAt(), destination.createdAt);
	}

}
