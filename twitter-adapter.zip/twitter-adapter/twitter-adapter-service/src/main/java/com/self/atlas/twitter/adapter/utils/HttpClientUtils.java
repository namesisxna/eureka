package com.self.atlas.twitter.adapter.utils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.ParseException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class HttpClientUtils {
	@Autowired
	public HttpClient client;

	public  JsonNode httpPost(String url,String input) {
		JsonNode jsonode = null;
		HttpPost post = new HttpPost(url);

		try {
			//HttpClient client= new DefaultHttpClient();
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
			nameValuePairs.add(new BasicNameValuePair("input",
					input));
			post.setEntity(new UrlEncodedFormEntity(nameValuePairs));
			HttpResponse response = client.execute(post);
			String json = EntityUtils.toString(response.getEntity());
			System.out.println("---^^^^" + json);

			ObjectMapper mapper = new ObjectMapper();
			jsonode = mapper.readTree(json);
			
		} catch (ParseException | IOException e) {
			e.printStackTrace();
		}
		return jsonode;
	}
	public static void main(String[] args) {
		HttpClientUtils httpClientUtils = new HttpClientUtils();
		JsonNode httpPost = httpClientUtils.httpPost("http://127.0.0.1:8000/createEmotionScore", "This is sample");
		httpPost.forEach((result)->{
			System.out.println(result.get("input"));
		});
		
		
	}

}
