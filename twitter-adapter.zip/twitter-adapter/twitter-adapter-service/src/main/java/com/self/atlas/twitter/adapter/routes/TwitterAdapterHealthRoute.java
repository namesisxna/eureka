package com.self.atlas.twitter.adapter.routes;

import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

@Component
public class TwitterAdapterHealthRoute extends RouteBuilder {

    @Override
    public void configure() throws Exception {
    	
    rest()
    	.get("/health")
		.id("health")
		.description("Health Check Endpoint")
		.outType(String.class)
		.to("direct:health");
	from("direct:health").transform().constant("OK")
		.setHeader(Exchange.CONTENT_TYPE, constant("text/plain"))
		.setHeader(Exchange.HTTP_RESPONSE_CODE, constant("200"));
    }

}
