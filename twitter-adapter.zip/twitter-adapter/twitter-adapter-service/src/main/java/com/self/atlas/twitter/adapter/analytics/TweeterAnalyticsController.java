package com.self.atlas.twitter.adapter.analytics;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;
@Component
public class TweeterAnalyticsController extends RouteBuilder {

	@Override
	public void configure() throws Exception {
		// TODO Auto-generated method stub
		
		from("quartz://myGroup/myTimerName?cron=0+0/1+*+?+*+MON-SUN")
		.bean(TweeterAnalyticsService.class,"buildInReplyAnalysis");
		
	}

}
