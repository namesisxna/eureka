package com.self.atlas.twitter.adapter.routes.impl;

import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

import com.self.atlas.twitter.adapter.service.TweeterAdapterTimelineService;

@Component
public class TwitterAdapterTimelineImplementationRoute extends RouteBuilder {

	
	
	private String consumerKey;
	private String  consumerSecret;
	private String  accessToken;
	private String  accessTokenSecret;
	

	@Override
	public void configure() throws Exception {
		// AggregationStrategy aggregationStrategy = new
		// ExampleAggregationStrategy();

		
		// from("direct:test")
		// .bean(MailNotificationHelperBean.class,"setHeaders")
		// //.to("activemq:queue:testQueue?disableReplyTo=true")
		// //.to("smtp://smtp.gmail.com:25?password=war7118865ning&username=sumitdatta2015&mail.smtp.starttls.enable=true&mail.smtp.socketFactory.class=javax.net.ssl.SSLSocketFactory")
		// .recipientList(simple("smtp://${property.X-SMTP-SERVER}:${property.X-SMTP-SERVER-PORT}?${property.X-SMTP-QUERY}"))
		// .bean(MailNotificationHelperBean.class,"printHeaders");

//		from("direct:postNotification").bean(MailNotificationHelperBean.class, "sendMail")
//				.recipientList(
//						simple("smtp://${property.X-SMTP-SERVER}:${property.X-SMTP-SERVER-PORT}?${property.X-SMTP-QUERY}"))
//				.bean(MailNotificationHelperBean.class, "printHeaders").setBody(constant("email sent successfully "));

		// from("direct:sendNotificationOnQueueEvent").log("xsds");
		// .recipientList(simple("activemq:queue:${header.queueId}?disableReplyTo=true"));

		// from("activemq:queue:notification-queue?disableReplyTo=true").to("direct:A");
		// from("direct:A").log("${body}");

		// from("activemq:queue:notification-queue?disableReplyTo=true").to("seda:A");
		// from("activemq:test?disableReplyTo=true").log("${body}");
		// from("file://C:/notification-directory?fileName=recipientlist.csv&noop=true").startupOrder(2).unmarshal()
		// .csv().bean(CSVProcessor.class,"processData").to("direct:B");

		// from("file://D:/notification-directory?fileName=mail.txt&noop=true").bean(CSVProcessor.class,"populateBody").to("direct:B");
		// from("activemq:queue:notification-queue")
		// .enrich("activemq:queue:notification-address-queue",aggregationStrategy);

		// from("direct:B").to("activemq:queue:notification-address?disableReplyTo=true");

		// from("file://C:/notification-directory?fileName=recipientlist.csv&noop=true").unmarshal().csv()
		// .bean(CSVProcessor.class,"processData").to("activemq:queue:notification-address-queue?deliveryPersistent=true");

		// from("activemq:queue:mail-notification-queue")
		// .bean(MailNotificationHelperBean.class,"sendMailOnQueueEvent")
		// .recipientList(simple("smtp://${property.X-SMTP-SERVER}:${property.X-SMTP-SERVER-PORT}?${property.X-SMTP-QUERY}"))
		// .setBody(constant("email sent successfully "));

		
		from("direct:getTimelineTweets")
			.id("getTimelineTweetsImplRoute")
			.log("Entering getTimelineTweetImplRoute")
			.bean(TweeterAdapterTimelineService.class,"getTimelineTweets")
			.setHeader(Exchange.HTTP_RESPONSE_CODE,constant(200))
			.log("Exiting getTimelineTweetImplRoute");
		
		from("direct:postTimelineTweets")
			.id("postTimeLineTweetsImplRoute")
			.log("Entered----postTweetRouteImpl")
			.bean(TweeterAdapterTimelineService.class,"postTimelineTweet")
		//.recipientList(simple(
			//	"twitter://timeline/user?consumerKey=CHxQ7p63eKDG2Dj5s5trNY2ZC&consumerSecret=LS7bQ2lGXrnKMmwTacKabAX3Wgud6Gsbyut8ECnaamojI8N1Vv&accessToken=746593198718464000-9hjZsUrg15bkJj7ZZV3beD6tKZVurMH&accessTokenSecret=ZHtk0kMM25IofHA98M8eM0LEPG5GLcbUWMOJCCrOPgLbi"))
			.setHeader(Exchange.HTTP_RESPONSE_CODE,constant(201));
		
		from("direct:deleteTimelineTweet")
			.id("deleteTimelineTweetImplRoute")
			.log("Entering deleteTimelineTweetImplRoute")
			.bean(TweeterAdapterTimelineService.class,"deleteTimelineTweet")
			.setHeader(Exchange.HTTP_RESPONSE_CODE,constant(200))
			.log("Exiting deleteTimelineTweetImplRoute");
		
		from("direct:getFavoriteTweets")
			.id("getFavoriteTweetsImplRoute")
			.log("Entering getFavoriteTweetsImplRoute")
			.bean(TweeterAdapterTimelineService.class,"getFavoriteTweets")
			.setHeader(Exchange.HTTP_RESPONSE_CODE,constant(200))
			.log("Exiting getFavoriteTweetsImplRoute");
		from("direct:updateTweetTofavorite")
			.id("updateTweetTofavoriteImplRoute")
			.log("Entering updateTweetTofavoriteImplRoute")
			.bean(TweeterAdapterTimelineService.class,"updateTweetTofavoriteImplRoute")
			.setHeader(Exchange.HTTP_RESPONSE_CODE,constant(200))
			.log("Exiting updateTweetTofavoriteImplRoute");
		
		
//		from("direct:getPeriodicStatus")
//		.id("getPeriodicStatusRoute")
//		.log("Entered----getPeriodicStatusRouteImpl")
		//.bean(MailNotificationHelperBean.class,"populatePostTweet")
		//from("timer://foo?delay=60").
//		from("twitter://timeline/home?delay=60000&type=polling&consumerKey=CHxQ7p63eKDG2Dj5s5trNY2ZC&consumerSecret=LS7bQ2lGXrnKMmwTacKabAX3Wgud6Gsbyut8ECnaamojI8N1Vv&accessToken=746593198718464000-9hjZsUrg15bkJj7ZZV3beD6tKZVurMH&accessTokenSecret=ZHtk0kMM25IofHA98M8eM0LEPG5GLcbUWMOJCCrOPgLbi")
//		.bean(MailNotificationHelperBean.class,"getPeriodicTweetStatus");
		
		from("direct:searchAllStatus")
		.id("searchAllStatusRoute")
		.log("Entered----searchAllStatusRoute")
		.setHeader("CamelTwitterKeywords", header("keyword"))
		.recipientList(simple(
				"twitter://search?type=direct&consumerKey=CHxQ7p63eKDG2Dj5s5trNY2ZC&consumerSecret=LS7bQ2lGXrnKMmwTacKabAX3Wgud6Gsbyut8ECnaamojI8N1Vv&accessToken=746593198718464000-9hjZsUrg15bkJj7ZZV3beD6tKZVurMH&accessTokenSecret=ZHtk0kMM25IofHA98M8eM0LEPG5GLcbUWMOJCCrOPgLbi"))
		.setHeader(Exchange.HTTP_RESPONSE_CODE,constant(200));
		
		
		from("direct:genericSearch")
		.id("genericSearchRoute")
		.log("Entered----genericSearchRoute")
		.setHeader("CamelTwitterKeywords", header("keyword"))
		.recipientList(simple(
				"twitter://search?consumerKey=CHxQ7p63eKDG2Dj5s5trNY2ZC&consumerSecret=LS7bQ2lGXrnKMmwTacKabAX3Wgud6Gsbyut8ECnaamojI8N1Vv&accessToken=746593198718464000-9hjZsUrg15bkJj7ZZV3beD6tKZVurMH&accessTokenSecret=ZHtk0kMM25IofHA98M8eM0LEPG5GLcbUWMOJCCrOPgLbi"))
		.bean(TweeterAdapterTimelineService.class,"populateGenericSearchResp")
		.setHeader(Exchange.HTTP_RESPONSE_CODE,constant(200));

		// .bean(MailNotificationHelperBean.class,"setHeaders")
		// //.to("activemq:queue:testQueue?disableReplyTo=true")
		// //.to("smtp://smtp.gmail.com:25?password=war7118865ning&username=sumitdatta2015&mail.smtp.starttls.enable=true&mail.smtp.socketFactory.class=javax.net.ssl.SSLSocketFactory")
		// .recipientList(simple("smtp://${property.X-SMTP-SERVER}:${property.X-SMTP-SERVER-PORT}?${property.X-SMTP-QUERY}"))
		// .bean(MailNotificationHelperBean.class,"printHeaders");

	}

}
