package com.self.atlas.twitter.adapter.routes;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.rest.RestBindingMode;
import org.apache.camel.model.rest.RestParamType;
import org.springframework.social.twitter.api.Tweet;
import org.springframework.stereotype.Component;

import com.self.atlas.twitter.adapter.model.TweetMessage;



@Component
public class TwitterAdapterTimelineInterfaceRoute extends RouteBuilder {

    @Override
    public void configure() throws Exception {
	
	restConfiguration()
		.component("{{server.component}}")
		.host("{{server.host}}").port("{{server.port}}")
		.bindingMode(RestBindingMode.json)
		.dataFormatProperty("prettyPrint", "true")
		.contextPath("/{{service.name}}/{{service.version}}")
		.apiContextPath("/")
		.apiProperty("api.title", "{{api.title}}")
		.apiProperty("api.version", "{{api.version}}")
		.apiProperty("apiContextIdListing", "{{apiContextIdListing}}")
		.apiProperty("apiContextIdPattern", "{{apiContextIdPattern}}")
		.apiProperty("api.description", "{{api.description}}")
		.apiProperty("api.termsOfService", "{{api.termsOfService}}")
		.apiProperty("api.contact.name", "{{api.contact.name}}")
		.apiProperty("api.contact.email", "{{api.contact.email}}")
		.apiProperty("api.contact.url", "{{api.contact.url}}")
		.apiProperty("api.license.name", "{{api.license.name}}")
		.apiProperty("api.license.url", "{{api.license.url}}");
	
	rest()
			.get("/timeline/tweets")
			 .id("getTimelineTweets")
	         .description("test Endpoint")
	        		.param()
	        			.name("type")
	        			.type(RestParamType.query)
	        			.description("type of timelne available option user/home default home")
	        		.endParam()
	        		.param()
	        			.name("pageSize")
	        			.type(RestParamType.query)
	        			.description("no of tweets to be fetched")
	        		.endParam()
	        		.param()
	        			.name("sinceId")
	        			.type(RestParamType.query)
	        			.description("tweets will be fetched after this statusId mandatory if max id is provided")
	        		.endParam()
	        		.param()
	        			.name("maxId")
	        			.type(RestParamType.query)
	        			.description("tweets will be fetched before this statusId default is -1L means recent")
	        		.endParam()
	         .outType(Tweet[].class)
	         .to("direct:getTimelineTweets")
			
   	       .post("/timeline/tweets")
	        	.id("postTimelineTweet")
	        	.description("test Endpoint")
	        	.type(TweetMessage.class)
	        	.outType(Tweet.class)
	        	.to("direct:postTimelineTweets")
	        	
	       .delete("/timeline/tweets/{statusId}")
	       		.id("deleteTimelineTweet")
	       		.description("")
	       		.param()
	        		.name("statusId")
	        		.type(RestParamType.path)
	        		.description("statusId of the tweet to be deleted")
	        	.endParam()
	       		.to("direct:deleteTimelineTweet")
	       		
	       .get("/timeline/favorites")
	       		.id("getFavoriteTweets")
	       		.description("")
	       			.param()
	        			.name("userId")
	        			.type(RestParamType.query)
	        			.description("favorite tweets will be fetched for the given userId default 20 tweets")
	        		.endParam()
	        		.param()
	        			.name("screenName")
	        			.type(RestParamType.query)
	        			.description("favorite tweets will be fetched for the given screenName default 20 tweets")
	        		.endParam()
	        		.param()
	        			.name("pageSize")
	        			.type(RestParamType.query)
	        			.description("no of favorite tweets to be fetched")
	        		.endParam()
	       		.outType(Tweet[].class)
	       		.to("direct:getFavoriteTweets")
	       	.put("/timeline/favorites/{statusId}")
	       		.id("updateTweetTofavorite")
	       		.description("endpoint to add a tweet in favorite list")
	       		.param()
	        		.name("statusId")
	        		.type(RestParamType.path)
	        		.description("statusId of the tweet to be added in favorite list")
	        	.endParam()
	       		.to("direct:updateTweetTofavorite")
	       		
	        
	        .get("/searchAllStatus")
	        		.id("searchAllStatus")
	        		.description("test Endpoint")
	        			.param()
	        			.name("keyword")
	        			.type(RestParamType.query)
	        			.description("keyword to search all twitter status")
	        			.endParam()
	        		.to("direct:searchAllStatus")
	        		
	        .get("/genericSearch")
	        		.id("genericSearch")
	        		.description("test Endpoint")
	        			.param()
	        			.name("keyword")
	        			.type(RestParamType.query)
	        			.description("keyword to do generic search")
	        			.endParam()
	        		.to("direct:genericSearch");
	        
//	       .post("/postNotification")
//	        		.id("postNotification")
//	        		.description("sendNotification")
//	        		.type(MailNotificationModel.class)
//	        		.outType(String.class)
//	        		.to("direct:postNotification")
//	        .get("/sendNotificationOnQueueEvent/{queueId}")
//	        		.id("sendNotificationOnQueueEvent")
//	        		.description("sendNotificationOnQueueEvent")
//	        		.param().name("queueId").type(path).description("queueId").dataType("string").endParam()
//	        		.outType(String.class)
//	        		.to("direct:sendNotificationOnQueueEvent")
	        		
	         
	
    }
}