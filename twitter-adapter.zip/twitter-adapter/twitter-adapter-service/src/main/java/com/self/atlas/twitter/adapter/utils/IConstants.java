package com.self.atlas.twitter.adapter.utils;

public interface IConstants {
	interface TIMELINE_TYPE {
		String USER="USER";
		String HOME="HOME";
				
	}
	
}
