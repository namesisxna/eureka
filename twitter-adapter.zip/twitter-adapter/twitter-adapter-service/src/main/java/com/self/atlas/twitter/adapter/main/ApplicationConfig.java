package com.self.atlas.twitter.adapter.main;

import javax.servlet.MultipartConfigElement;

import org.apache.camel.CamelContext;
import org.apache.camel.component.servlet.CamelHttpTransportServlet;
import org.apache.camel.spring.SpringCamelContext;
import org.apache.camel.spring.boot.CamelContextConfiguration;
import org.apache.http.client.config.CookieSpecs;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.jasypt.encryption.StringEncryptor;
import org.jasypt.encryption.pbe.PooledPBEStringEncryptor;
import org.jasypt.encryption.pbe.config.SimpleStringPBEConfig;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.MultipartConfigFactory;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.social.twitter.api.Twitter;
import org.springframework.social.twitter.api.impl.TwitterTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.self.atlas.twitter.adapter.mappings.TweetToTweetRepEntityMappings;
import com.self.atlas.twitter.adapter.utils.HttpClientUtils;

@Configuration
public class ApplicationConfig {
	@Autowired
	private ObjectMapper objectMapper;
	
	@Value("${twitter.consumerKey}")
	private String consumerKey;
	
	@Value("${twitter.consumerSecret}")
	private String consumerSecret;
	
	@Value("${twitter.accessToken}")
	private String accessToken;
	
	@Value("${twitter.accessTokenSecret}")
	private String accessTokenSecret;

	 

	@Bean
	CamelContextConfiguration contextConfiguration(
			@Value("${service.name}") String name) {
		return new CamelContextConfiguration() {

			@Override
			public void beforeApplicationStart(CamelContext cc) {
				SpringCamelContext springCamelContext = (SpringCamelContext) cc;
				springCamelContext.setName(name);
				objectMapper.configure(
						SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
			}

			@Override
			public void afterApplicationStart(CamelContext cc) {

			}
		};
	}

	@Bean
	public ServletRegistrationBean camelServlet(
			@Value("${service.name}") String serviceName,
			@Value("${service.version}") String serviceVersion) {
		ServletRegistrationBean servlet = new ServletRegistrationBean();
		servlet.setServlet(new CamelHttpTransportServlet());
		servlet.addUrlMappings(String.format("/%s/%s/*", serviceName,
				serviceVersion));
		servlet.setName("CamelServlet");
		return servlet;
	}

	@Bean
	public ModelMapper modelMapper() {
		return new ModelMapper();
	}

	@Bean
	CloseableHttpClient httpClient() {
		PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager();
		// since most services only connect to a single backend
		// we use the same value for max per-route and total
		connectionManager.setDefaultMaxPerRoute(1000);
		connectionManager.setMaxTotal(1000);

		RequestConfig requestConfig = RequestConfig.custom()
				.setConnectTimeout(1000)
				.setSocketTimeout(1000)
				.setCookieSpec(CookieSpecs.STANDARD).build();

		return HttpClients.custom().setConnectionManager(connectionManager)
				.setDefaultRequestConfig(requestConfig).build();
	}

	
	@Bean
	public HttpClientUtils getHttpClientUtils(){
		return new HttpClientUtils();
	}
	
	@Bean
	public TweetToTweetRepEntityMappings getTweetToTweetRepEntityMappings(){
		return new TweetToTweetRepEntityMappings();
	}
	
	@Bean
	public Twitter getTwitterTemplate() {
		Twitter twitter = new TwitterTemplate(consumerKey, consumerSecret, accessToken, accessTokenSecret);
		return twitter;
	}
	// @Bean
	// public ConnectionFactory activemqConnectionFactory() {
	// RedeliveryPolicy rp = new RedeliveryPolicy();
	// rp.setMaximumRedeliveries(RedeliveryPolicy.NO_MAXIMUM_REDELIVERIES);
	//
	// ActiveMQConnectionFactory connectionFactory = new
	// ActiveMQConnectionFactory();
	// connectionFactory.setBrokerURL("tcp://localhost:61616?jms.prefetchPolicy.all=1");
	// connectionFactory.setUserName("admin");
	// connectionFactory.setPassword("admin");
	// connectionFactory.setRedeliveryPolicy(rp);
	//
	// PooledConnectionFactory pcf = new
	// PooledConnectionFactory(connectionFactory);
	// return pcf;
	// }

	// @Bean
	// public JmsTransactionManager jmsTransactionManager(ConnectionFactory
	// connectionFactory) {
	// return new JmsTransactionManager(connectionFactory);
	// }

	/**
	 * @return activemq camel component
	 */
	// @Bean
	// public ActiveMQComponent activemq(ConnectionFactory connectionFactory) {
	// ActiveMQComponent activeMqComponent = new ActiveMQComponent();
	// activeMqComponent.setTestConnectionOnStartup(true);
	// activeMqComponent.setTransacted(true);
	// activeMqComponent.setConnectionFactory(connectionFactory);
	// activeMqComponent.setTransactionManager(jmsTransactionManager(connectionFactory));
	//
	// return activeMqComponent;
	// }

	@Bean(name = "encryptorBean")
	public StringEncryptor stringEncryptor() {
		PooledPBEStringEncryptor encryptor = new PooledPBEStringEncryptor();
		SimpleStringPBEConfig config = new SimpleStringPBEConfig();
		config.setPassword("password");
		config.setAlgorithm("PBEWithMD5AndDES");
		config.setKeyObtentionIterations("1000");
		config.setPoolSize("1");
		config.setProviderName("SunJCE");
		config.setSaltGeneratorClassName("org.jasypt.salt.RandomSaltGenerator");
		config.setStringOutputType("base64");
		encryptor.setConfig(config);
		return encryptor;
	}

	@Bean
	public MultipartConfigElement multipartConfigElement() {
		MultipartConfigFactory factory = new MultipartConfigFactory();
		factory.setMaxFileSize("10MB");
		factory.setMaxRequestSize("10MB");
		return factory.createMultipartConfig();
	}

}
