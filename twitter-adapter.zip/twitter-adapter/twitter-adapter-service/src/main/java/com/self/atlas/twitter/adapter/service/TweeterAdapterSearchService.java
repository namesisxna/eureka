package com.self.atlas.twitter.adapter.service;

import java.util.List;
import java.util.Map;

import org.apache.camel.Exchange;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.social.twitter.api.SearchOperations;
import org.springframework.social.twitter.api.SearchResults;
import org.springframework.social.twitter.api.Tweet;
import org.springframework.social.twitter.api.Twitter;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.self.atlas.twitter.adapter.dao.TweeterReplyRepository;
import com.self.atlas.twitter.adapter.entity.TweetRepEntity;
import com.self.atlas.twitter.adapter.mappings.TweetToTweetRepEntityMappings;

@Component
public class TweeterAdapterSearchService {

	@Autowired
	private Twitter twitter;
	private static final Logger LOG = LoggerFactory
			.getLogger(TweeterAdapterSearchService.class);

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private TweeterReplyRepository tweeterReplyRepository;

	@Autowired
	private TweetToTweetRepEntityMappings tweetToTweetRepEntityMappings;

	public List<Tweet> getReplyTweet(Exchange exchange) {
		LOG.info("Entered TweeterAdapterSearchService#getReplyTweet");
		Map<String, Object> headers = exchange.getIn().getHeaders();
		if (headers.get("userScreenName") == null
				&& headers.get("userScreenName").toString().isEmpty()) {
			throw new RuntimeException("username can not be null");
		}
		String userScreenName = headers.get("userScreenName").toString();
		if (headers.get("statusId") == null) {
			throw new RuntimeException("statusId can not be null");
		}
		int pageSize = headers.get("pageSize") != null ? Integer
				.valueOf(headers.get("pageSize").toString()) : 10;
		Long statusId = Long.valueOf(headers.get("statusId").toString());
		SearchOperations searchOperations = twitter.searchOperations();
		SearchResults search = searchOperations.search("to:" + userScreenName,
				pageSize, statusId, -1L);

		List<Tweet> repTweets = search.getTweets();
		// modelMapper.addMappings(tweetToTweetRepEntityMappings);

		search.getTweets()
				.forEach(
						(tweet) -> {
							System.out.println(tweet.getText());
							boolean enable_analytics = headers
									.get("enable_analytics") != null ? (Boolean) headers
									.get("enable_analytics") : false;
							if (enable_analytics) {

								// modelMapper.addMappings((mapper) -> {});
								TweetRepEntity tweetRepEntity = modelMapper
										.map(tweet, TweetRepEntity.class);
								try {
									tweeterReplyRepository.save(tweetRepEntity);
								} catch (Exception e) {
									// TODO: handle exception
								}

							}
						});

		return repTweets;

	}

}
