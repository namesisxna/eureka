package com.self.atlas.twitter.adapter.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity(name = "tweetReplyAnalytics")
public class TweetRepAnalyticsEntity {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Column(nullable = false,unique=true)
	public long status_id;
	
	private String input;
	private Double anger;
	private Double anticipation;
	private Double disgust;
	private Double fear;
	private Double joy;
	private Double sadness;
	private Double surprise;
	private Double trust;
	private Double negative;
	private Double positive;
	public long getStatus_id() {
		return status_id;
	}
	public void setStatus_id(long status_id) {
		this.status_id = status_id;
	}
	public String getInput() {
		return input;
	}
	public void setInput(String input) {
		this.input = input;
	}
	public Double getAnger() {
		return anger;
	}
	public void setAnger(Double anger) {
		this.anger = anger;
	}
	public Double getAnticipation() {
		return anticipation;
	}
	public void setAnticipation(Double anticipation) {
		this.anticipation = anticipation;
	}
	public Double getDisgust() {
		return disgust;
	}
	public void setDisgust(Double disgust) {
		this.disgust = disgust;
	}
	public Double getFear() {
		return fear;
	}
	public void setFear(Double fear) {
		this.fear = fear;
	}
	public Double getJoy() {
		return joy;
	}
	public void setJoy(Double joy) {
		this.joy = joy;
	}
	public Double getSadness() {
		return sadness;
	}
	public void setSadness(Double sadness) {
		this.sadness = sadness;
	}
	public Double getSurprise() {
		return surprise;
	}
	public void setSurprise(Double surprise) {
		this.surprise = surprise;
	}
	public Double getTrust() {
		return trust;
	}
	public void setTrust(Double trust) {
		this.trust = trust;
	}
	public Double getNegative() {
		return negative;
	}
	public void setNegative(Double negative) {
		this.negative = negative;
	}
	public Double getPositive() {
		return positive;
	}
	public void setPositive(Double positive) {
		this.positive = positive;
	}
	
	
	

}
