package com.self.atlas.twitter.adapter.service;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.camel.Exchange;
import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.UrlResource;
import org.springframework.social.twitter.api.ListOperations;
import org.springframework.social.twitter.api.SearchOperations;
import org.springframework.social.twitter.api.SearchResults;
import org.springframework.social.twitter.api.TimelineOperations;
import org.springframework.social.twitter.api.Tweet;
import org.springframework.social.twitter.api.TweetData;
import org.springframework.social.twitter.api.Twitter;
import org.springframework.social.twitter.api.impl.TwitterTemplate;
import org.springframework.stereotype.Component;

import twitter4j.Status;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.self.atlas.twitter.adapter.dao.TweeterRepository;
import com.self.atlas.twitter.adapter.entity.TweetEntity;
import com.self.atlas.twitter.adapter.model.TweetMessage;
import com.self.atlas.twitter.adapter.model.TwitterStatusModel;
import com.self.atlas.twitter.adapter.utils.HttpClientUtils;
import com.self.atlas.twitter.adapter.utils.IConstants;

@Component
public class TweeterAdapterTimelineService {
	private static final Logger LOG = LoggerFactory
			.getLogger(TweeterAdapterTimelineService.class);

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private HttpClientUtils httpClientUtils;
	@Autowired
	private TweeterRepository tweeterRepository;

	@Autowired
	private Twitter twitter;

	public List<Tweet> getTimelineTweets(Exchange exchange) {
		LOG.info("Entered TweeterAdapterTimelineService#getTimelineTweets");
		Map<String, Object> headers = exchange.getIn().getHeaders();
		TimelineOperations timelineOperations = twitter.timelineOperations();
		int pagesize = headers.get("pageSize") != null ? Integer
				.valueOf(headers.get("pageSize").toString()) : 0;
		String type = headers.get("type") != null ? 
				headers.get("type").toString().toUpperCase()
				.equals(IConstants.TIMELINE_TYPE.HOME) ? IConstants.TIMELINE_TYPE.HOME
				: IConstants.TIMELINE_TYPE.USER
				: IConstants.TIMELINE_TYPE.HOME;
		Long maxId = headers.get("maxId") != null ? Long.valueOf(headers.get("maxId").toString()) : -1L;
		Long sinceId = headers.get("sinceId") != null ? Long.valueOf( headers.get("sinceId").toString()) : null;

		if (pagesize == 0) {
			if (type.equals(IConstants.TIMELINE_TYPE.HOME)) {
				List<Tweet> homeTimeline = timelineOperations.getHomeTimeline();
				LOG.info("Exiting TweeterAdapterTimelineService#getTimelineTweets");
				return homeTimeline;
			} else {
				List<Tweet> userTimeline = timelineOperations.getUserTimeline();
				LOG.info("Exiting TweeterAdapterTimelineService#getTimelineTweets");
				return userTimeline;
			}
		} else {
			if (type.equals(IConstants.TIMELINE_TYPE.HOME)) {
				if (maxId != null && sinceId != null) {
					List<Tweet> homeTimeline = timelineOperations
							.getHomeTimeline(pagesize, sinceId, maxId);
					LOG.info("Exiting TweeterAdapterTimelineService#getTimelineTweets");
					return homeTimeline;
				} else {
					List<Tweet> homeTimeline = timelineOperations
							.getHomeTimeline(pagesize);
					LOG.info("Exiting TweeterAdapterTimelineService#getTimelineTweets");
					return homeTimeline;
				}

			} else {
				if (maxId != null && sinceId != null) {
					List<Tweet> userTimeline = timelineOperations
							.getUserTimeline(pagesize, sinceId, maxId);
					LOG.info("Exiting TweeterAdapterTimelineService#getTimelineTweets");
					return userTimeline;
				} else {
					List<Tweet> userTimeline = timelineOperations
							.getUserTimeline(pagesize);
					LOG.info("Exiting TweeterAdapterTimelineService#getTimelineTweets");
					return userTimeline;
				}
			}
		}
	}

	public Tweet postTimelineTweet(Exchange exchange) {
		LOG.info("Entered TweeterAdapterTimelineService#postTimelineTweet");
		Map<String, Object> headers = exchange.getIn().getHeaders();
		TweetMessage tweetMessage = exchange.getIn().getBody(
				TweetMessage.class);
		TimelineOperations timelineOperations = twitter.timelineOperations();
		
		TweetData tweetData = new TweetData(
				tweetMessage.getTweetMessage());
		if (tweetMessage.getInReplyToStatus() != null)
			tweetData.inReplyToStatus(tweetMessage
					.getInReplyToStatus());
		if(tweetMessage.getPlaceId()!=null)
			tweetData.atPlace(tweetMessage.getPlaceId());
		if (tweetMessage.getMediaUrl() != null) {
			try {
				URI uri = new URI(tweetMessage.getMediaUrl());
				tweetData.withMedia(new UrlResource(uri));

			} catch (URISyntaxException | MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		Tweet updateStatus = timelineOperations.updateStatus(tweetData);
		if(tweetMessage.isEnable_analytics()){
		PropertyMap<Tweet, TweetEntity> orderMap = new PropertyMap<Tweet, TweetEntity>() {
			  protected void configure() {
			    map(source.getId(), destination.status_id);
			    map(source.getText(), destination.text);
			    map(source.getCreatedAt(), destination.createdAt);
			  }
			};

			modelMapper.addMappings(orderMap);
		//modelMapper.addMappings((mapper) -> {});
		TweetEntity tweetEntity = modelMapper.map(updateStatus, TweetEntity.class);
		tweeterRepository.save(tweetEntity);
		}
		return updateStatus;
	}
	
	public void deleteTimelineTweet(Exchange exchange){
		Map<String, Object> headers = exchange.getIn().getHeaders();
		if(headers.get("statusId")==null)
			throw new RuntimeException("provide statusId to be deleted");
		Long tweetId = Long.valueOf(headers.get("statusId").toString());
		TimelineOperations timelineOperations = twitter.timelineOperations();
		timelineOperations.deleteStatus(tweetId);
	}
	
	public List<Tweet> getFavoriteTweets(Exchange exchange){
		Map<String, Object> headers = exchange.getIn().getHeaders();
		Long userId = headers.get("userId")!= null?Long.valueOf(headers.get("userId").toString()):null;
		String screenName = headers.get("screenName")!=null?headers.get("screenName").toString():null;
		Integer pageSize = headers.get("pageSize")!= null?Integer.valueOf(headers.get("pageSize").toString()):null;
		TimelineOperations timelineOperations = twitter.timelineOperations();
		//List<Tweet> favorites = timelineOperations.getFavorites();
		if(userId!=null){
			if(pageSize!=null){
			List<Tweet> favorites = timelineOperations.getFavorites(userId,pageSize);
			return favorites;
			}
			else {
				List<Tweet> favorites = timelineOperations.getFavorites(userId);
				return favorites;
			}
		}
		
		else if(screenName!=null){
			if(pageSize!=null){
			List<Tweet> favorites = timelineOperations.getFavorites(screenName,pageSize);
			return favorites;
			}
			else {
				List<Tweet> favorites = timelineOperations.getFavorites(screenName);
				return favorites;
			}
		}
		else {
			if(pageSize!=null){
				List<Tweet> favorites = timelineOperations.getFavorites(pageSize);
				return favorites;
				}
				else {
					List<Tweet> favorites = timelineOperations.getFavorites();
					return favorites;
				}
		}
	}
	
	public void updateTweetTofavoriteImplRoute(Exchange exchange){
		Map<String, Object> headers = exchange.getIn().getHeaders();
		if(headers.get("statusId")==null)
			throw new RuntimeException("provide statusId to add tweet in favorites");
		Long tweetId = Long.valueOf(headers.get("statusId").toString());
		TimelineOperations timelineOperations = twitter.timelineOperations();
		timelineOperations.addToFavorites(tweetId);
		
	}

	public void getPeriodicTweetStatus(Exchange exchange) {
		LOG.info("Entered MailNotificationHelperBean#populatePostTweet");
		Map<String, Object> headers = exchange.getIn().getHeaders();
		LOG.info(exchange.getIn().getBody(String.class));

	}

	public void populateGenericSearchResp(Exchange exchange) {

		LOG.info("Entered MailNotificationHelperBean#populateGenericSearchResp");
		Map<String, Object> headers = exchange.getIn().getHeaders();
		Status[] tweets = exchange.getIn().getBody(Status[].class);
		List<TwitterStatusModel> statusModels = new ArrayList<TwitterStatusModel>();

		for (Status tweet : tweets) {
			TwitterStatusModel model = modelMapper.map(tweet,
					TwitterStatusModel.class);

			getEmotionScores("http://127.0.0.1:8000/createEmotionScore",
					tweet.getText());
			statusModels.add(model);
			System.out.println("--text--" + tweet.getText());
		}
		exchange.getIn().setBody(statusModels);

	}

	public void getEmotionScores(String url, String input) {
		JsonNode jsonode = httpClientUtils.httpPost(url, input);
		if (jsonode.isArray()) {
			for (final JsonNode objNode : jsonode) {
				System.out.println("anger: " + objNode.get("anger")
						+ "anticipation: " + objNode.get("anticipation")
						+ "disgust: " + objNode.get("disgust") + "fear: "
						+ objNode.get("fear") + "joy: " + objNode.get("joy")
						+ "sadness: " + objNode.get("sadness") + "surprise: "
						+ objNode.get("surprise") + "trust: "
						+ objNode.get("trust"));
			}

		}
	}

	public static void main(String[] args) {
		String consumerKey = "CHxQ7p63eKDG2Dj5s5trNY2ZC"; 
		String consumerSecret = "LS7bQ2lGXrnKMmwTacKabAX3Wgud6Gsbyut8ECnaamojI8N1Vv"; 
		String accessToken = "746593198718464000-9hjZsUrg15bkJj7ZZV3beD6tKZVurMH"; 
		String accessTokenSecret = "ZHtk0kMM25IofHA98M8eM0LEPG5GLcbUWMOJCCrOPgLbi";
		Twitter twitter = new TwitterTemplate(consumerKey, consumerSecret,
				accessToken, accessTokenSecret);
		SearchOperations searchOperations = twitter.searchOperations();
		ListOperations listOperations = twitter.listOperations();

		SearchResults search = searchOperations.search("obama");
		List<Tweet> tweets = search.getTweets();
		tweets.forEach((tweet) -> {
			System.out.println("actual tweet text-->" + tweet.getText());
			System.out.println(tweet.getId());
			List<Tweet> listStatuses = listOperations.getListStatuses(tweet
					.getId());
			listStatuses.forEach((retweet) -> {
				System.out.println("retweet status text--->"
						+ retweet.getText());
			});

		});
	}

}