package com.self.atlas.twitter.adapter.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cloud.config.server.EnableConfigServer;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(scanBasePackages = "com.self.atlas.twitter.adapter")
@EnableJpaRepositories("com.self.atlas.twitter.adapter.dao")
@EntityScan("com.self.atlas.twitter.adapter.entity")
@EnableConfigServer
public class Application {

    public static void main(String[] args) {
	SpringApplication.run(Application.class, args);
    }

}
