package com.self.atlas.twitter.adapter.utils;

import java.util.List;

import org.springframework.social.twitter.api.ListOperations;
import org.springframework.social.twitter.api.SearchOperations;
import org.springframework.social.twitter.api.SearchResults;
import org.springframework.social.twitter.api.StreamingOperations;
import org.springframework.social.twitter.api.TimelineOperations;
import org.springframework.social.twitter.api.Tweet;
import org.springframework.social.twitter.api.Twitter;
import org.springframework.social.twitter.api.impl.TwitterTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class TwitterTest {

	public static void main(String[] args) {
		TwitterTest twitterTest = new TwitterTest();
		Twitter twitter = twitterTest.getConnection();

		// TimelineOperations timelineOperations = twitter.timelineOperations();
		long tweetId = 1061453835455975424L;
		// twitterTest.getReplyText(tweetId, twitter);
		//twitterTest.getReplyTweet(twitter,tweetId);
		// Tweet status = timelineOperations.getStatus(1061598511324692481L);
		// ObjectMapper objectMapper = new ObjectMapper();
		// try {
		// String writeValueAsString = objectMapper.writeValueAsString(status);
		// System.out.println(writeValueAsString);
		// } catch (JsonProcessingException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }
	String test = "1061453835455975424";
	Long id = Long.valueOf(test);
	System.out.println(id);

	}

	// public ArrayList<Status> getDiscussion(Status status, Twitter twitter) {
	// ArrayList<Status> replies = new ArrayList<>();
	//
	// ArrayList<Status> all = null;
	//
	// try {
	// long id = status.getId();
	// String screenname = status.getUser().getScreenName();
	//
	// Query query = new Query("@" + screenname + " since_id:" + id);
	//
	// System.out.println("query string: " + query.getQuery());
	//
	// try {
	// query.setCount(100);
	// } catch (Throwable e) {
	// // enlarge buffer error?
	// query.setCount(30);
	// }
	//
	// QueryResult result = twitter.search(query);
	// System.out.println("result: " + result.getTweets().size());
	//
	// all = new ArrayList<Status>();
	//
	// do {
	// System.out.println("do loop repetition");
	//
	// List<Status> tweets = result.getTweets();
	//
	// for (Status tweet : tweets)
	// if (tweet.getInReplyToStatusId() == id)
	// all.add(tweet);
	//
	// if (all.size() > 0) {
	// for (int i = all.size() - 1; i >= 0; i--)
	// replies.add(all.get(i));
	// all.clear();
	// }
	//
	// query = result.nextQuery();
	//
	// if (query != null)
	// result = twitter.search(query);
	//
	// } while (query != null);
	//
	// } catch (Exception e) {
	// e.printStackTrace();
	// } catch (OutOfMemoryError e) {
	// e.printStackTrace();
	// }
	// return replies;
	// }

	public Twitter getConnection() {

		String consumerKey = "CHxQ7p63eKDG2Dj5s5trNY2ZC"; 
		String consumerSecret = "LS7bQ2lGXrnKMmwTacKabAX3Wgud6Gsbyut8ECnaamojI8N1Vv"; 
		String accessToken = "746593198718464000-9hjZsUrg15bkJj7ZZV3beD6tKZVurMH"; 
		String accessTokenSecret = "ZHtk0kMM25IofHA98M8eM0LEPG5GLcbUWMOJCCrOPgLbi"; 
		Twitter twitter = new TwitterTemplate(consumerKey, consumerSecret, accessToken, accessTokenSecret);
		return twitter;

	}

	public void searchTweet(Twitter twitter) {

		SearchOperations searchOperations = twitter.searchOperations();
		ListOperations listOperations = twitter.listOperations();

		SearchResults search = searchOperations.search("obama");
		
		List<Tweet> tweets = search.getTweets();
		tweets.forEach((tweet) -> {
			System.out.println("actual tweet text-->" + tweet.getText());
			System.out.println(tweet.getId());
			List<Tweet> listStatuses = listOperations.getListStatuses(tweet.getId());
			listStatuses.forEach((retweet) -> {
				System.out.println("retweet status text--->" + retweet.getText());
			});

		});
	}

	public Tweet getTweetBySatusId(Long tweetId, Twitter twitter) {

		TimelineOperations timelineOperations = twitter.timelineOperations();
		

		Tweet status = timelineOperations.getStatus(1061598511324692481L);
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			String writeValueAsString = objectMapper.writeValueAsString(status);
			System.out.println(writeValueAsString);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return status;

	}

	// public void getReplyText(Long tweetId, Twitter twitter){
	// SearchOperations searchOperations = twitter.searchOperations();
	// SearchResults search = searchOperations.search("SumitDa49957154");
	// List<Tweet> tweets = search.getTweets();
	// tweets.forEach((tweet)->{
	// System.out.println("------"+tweet.getText());
	// System.out.println("----"+tweet.getInReplyToScreenName());
	// });
	//
	// }

	public void getMentionList(Twitter twitter, Long tweetId) {
		TimelineOperations timelineOperations = twitter.timelineOperations();
		List<Tweet> mentions = timelineOperations.getMentions();
		ObjectMapper objectMapper = new ObjectMapper();
		mentions.forEach((mention) -> {

		//	if (mention.getInReplyToStatusId() == tweetId) {
				System.out.println(mention.getFromUser());
				System.out.println(mention.getText());
			//}

		});

	}
	
	public void getReplyTweet(Twitter twitter, Long tweetId){
		SearchOperations searchOperations = twitter.searchOperations();
		SearchResults search = searchOperations.search("to:Sumitda86431668 ", 10, tweetId,-1L);
		search.getTweets().forEach((tweet)->{
			System.out.println(tweet.getText());
		});
		
	}

}
