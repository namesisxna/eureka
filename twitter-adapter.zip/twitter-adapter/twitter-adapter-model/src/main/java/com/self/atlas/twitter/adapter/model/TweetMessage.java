package com.self.atlas.twitter.adapter.model;

import java.io.Serializable;

public class TweetMessage implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -2321930178060802304L;
	private String tweetMessage;
	private String mediaUrl;
	private Long inReplyToStatus;
	private String placeId;
	private boolean enable_analytics;
	public String getTweetMessage() {
		return tweetMessage;
	}
	public void setTweetMessage(String tweetMessage) {
		this.tweetMessage = tweetMessage;
	}
	public String getMediaUrl() {
		return mediaUrl;
	}
	public void setMediaUrl(String mediaUrl) {
		this.mediaUrl = mediaUrl;
	}
	public Long getInReplyToStatus() {
		return inReplyToStatus;
	}
	public void setInReplyToStatus(Long inReplyToStatus) {
		this.inReplyToStatus = inReplyToStatus;
	}
	public String getPlaceId() {
		return placeId;
	}
	public void setPlaceId(String placeId) {
		this.placeId = placeId;
	}
	public boolean isEnable_analytics() {
		return enable_analytics;
	}
	public void setEnable_analytics(boolean enable_analytics) {
		this.enable_analytics = enable_analytics;
	}
}
