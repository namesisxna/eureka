package com.self.atlas.twitter.adapter.model;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "rateLimitStatus",
    "accessLevel",
    "id",
    "name",
    "email",
    "screenName",
    "location",
    "description",
    "descriptionURLEntities",
    "url",
    "followersCount",
    "status",
    "profileBackgroundColor",
    "profileTextColor",
    "profileLinkColor",
    "profileSidebarFillColor",
    "profileSidebarBorderColor",
    "profileUseBackgroundImage",
    "showAllInlineMedia",
    "friendsCount",
    "createdAt",
    "favouritesCount",
    "utcOffset",
    "timeZone",
    "profileBackgroundImageUrlHttps",
    "profileBackgroundTiled",
    "lang",
    "statusesCount",
    "translator",
    "listedCount",
    "withheldInCountries",
    "protected",
    "defaultProfile",
    "profileBannerIPadURL",
    "profileBackgroundImageURL",
    "profileBannerURL",
    "followRequestSent",
    "defaultProfileImage",
    "contributorsEnabled",
    "profileBannerIPadRetinaURL",
    "profileImageURLHttps",
    "originalProfileImageURL",
    "originalProfileImageURLHttps",
    "profileBannerRetinaURL",
    "biggerProfileImageURL",
    "profileBannerMobileRetinaURL",
    "profileBannerMobileURL",
    "profileImageURL",
    "miniProfileImageURL",
    "miniProfileImageURLHttps",
    "biggerProfileImageURLHttps",
    "geoEnabled",
    "verified",
    "urlentity"
})
public class User {

    
    @JsonProperty("id")
    private Long id;
    @JsonProperty("name")
    private String name;
    @JsonProperty("email")
    private Object email;
    @JsonProperty("screenName")
    private String screenName;
    @JsonProperty("location")
    private String location;
    @JsonProperty("description")
    private String description;
    @JsonProperty("descriptionURLEntities")
    private List<Object> descriptionURLEntities = null;
    @JsonProperty("url")
    private Object url;
    @JsonProperty("followersCount")
    private Integer followersCount;
    @JsonProperty("status")
    private Object status;
    @JsonProperty("friendsCount")
    private Integer friendsCount;
    @JsonProperty("createdAt")
    private Date createdAt;
    @JsonProperty("favouritesCount")
    private Integer favouritesCount;
    @JsonProperty("utcOffset")
    private Long utcOffset;
    @JsonProperty("timeZone")
    private Object timeZone;
    @JsonProperty("lang")
    private String lang;
    @JsonProperty("geoEnabled")
    private Boolean geoEnabled;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Object getEmail() {
		return email;
	}
	public void setEmail(Object email) {
		this.email = email;
	}
	public String getScreenName() {
		return screenName;
	}
	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public List<Object> getDescriptionURLEntities() {
		return descriptionURLEntities;
	}
	public void setDescriptionURLEntities(List<Object> descriptionURLEntities) {
		this.descriptionURLEntities = descriptionURLEntities;
	}
	public Object getUrl() {
		return url;
	}
	public void setUrl(Object url) {
		this.url = url;
	}
	public Integer getFollowersCount() {
		return followersCount;
	}
	public void setFollowersCount(Integer followersCount) {
		this.followersCount = followersCount;
	}
	public Object getStatus() {
		return status;
	}
	public void setStatus(Object status) {
		this.status = status;
	}
	public Integer getFriendsCount() {
		return friendsCount;
	}
	public void setFriendsCount(Integer friendsCount) {
		this.friendsCount = friendsCount;
	}
	public Date getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}
	public Integer getFavouritesCount() {
		return favouritesCount;
	}
	public void setFavouritesCount(Integer favouritesCount) {
		this.favouritesCount = favouritesCount;
	}
	public Long getUtcOffset() {
		return utcOffset;
	}
	public void setUtcOffset(Long utcOffset) {
		this.utcOffset = utcOffset;
	}
	public Object getTimeZone() {
		return timeZone;
	}
	public void setTimeZone(Object timeZone) {
		this.timeZone = timeZone;
	}
	public String getLang() {
		return lang;
	}
	public void setLang(String lang) {
		this.lang = lang;
	}
	public Boolean getGeoEnabled() {
		return geoEnabled;
	}
	public void setGeoEnabled(Boolean geoEnabled) {
		this.geoEnabled = geoEnabled;
	}
    

    }
