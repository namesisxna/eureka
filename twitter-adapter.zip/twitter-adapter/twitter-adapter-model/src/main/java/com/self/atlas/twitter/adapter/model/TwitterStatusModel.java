package com.self.atlas.twitter.adapter.model;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "rateLimitStatus", "accessLevel", "createdAt", "id",
		"text", "source", "inReplyToStatusId", "inReplyToUserId",
		"favoriteCount", "inReplyToScreenName", "geoLocation", "place",
		"retweetCount", "lang", "retweetedStatus", "userMentionEntities",
		"hashtagEntities", "mediaEntities", "extendedMediaEntities",
		"symbolEntities", "currentUserRetweetId", "scopes", "user",
		"withheldInCountries", "quotedStatus", "quotedStatusId",
		"possiblySensitive", "retweet", "urlentities", "favorited",
		"retweetedByMe", "contributors", "retweeted", "truncated" })
public class TwitterStatusModel {

	@JsonProperty("createdAt")
	private Date createdAt;
	@JsonProperty("text")
	private String text;
	@JsonProperty("source")
	private String source;

	@JsonProperty("inReplyToUserId")
	private Long inReplyToUserId;
	@JsonProperty("favoriteCount")
	private Integer favoriteCount;
	@JsonProperty("inReplyToScreenName")
	private Object inReplyToScreenName;

	@JsonProperty("place")
	private Object place;
	@JsonProperty("retweetCount")
	private Integer retweetCount;
	@JsonProperty("lang")
	private String lang;
	@JsonProperty("retweetedStatus")
	private TwitterStatusModel retweetedStatus;
	@JsonProperty("userMentionEntities")
	private List<Object> userMentionEntities = null;
	// @JsonProperty("hashtagEntities")
	// private List<Object> hashtagEntities = null;
	// @JsonProperty("mediaEntities")
	// private List<Object> mediaEntities = null;
	// @JsonProperty("extendedMediaEntities")
	// private List<Object> extendedMediaEntities = null;
	// @JsonProperty("symbolEntities")
	// private List<Object> symbolEntities = null;
	@JsonProperty("currentUserRetweetId")
	private Long currentUserRetweetId;
	// @JsonProperty("scopes")
	// private Object scopes;
	@JsonProperty("user")
	private User user;

	// @JsonProperty("quotedStatus")
	// private Object quotedStatus;
	// @JsonProperty("quotedStatusId")
	// private Integer quotedStatusId;
	// @JsonProperty("possiblySensitive")
	// private Boolean possiblySensitive;
	// @JsonProperty("retweet")
	// private Boolean retweet;
	// @JsonProperty("urlentities")
	// private List<Object> urlentities = null;
	@JsonProperty("favorited")
	private Boolean favorited;
	@JsonProperty("retweetedByMe")
	private Boolean retweetedByMe;

	// @JsonProperty("contributors")
	// private List<Object> contributors = null;
	// @JsonProperty("retweeted")
	// private Boolean retweeted;
	// @JsonProperty("truncated")
	// private Boolean truncated;
	// @JsonIgnore
	// private Map<String, Object> additionalProperties = new HashMap<String,
	// Object>();
	
	

	@JsonProperty("text")
	public String getText() {
		return text;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	@JsonProperty("text")
	public void setText(String text) {
		this.text = text;
	}

	@JsonProperty("source")
	public String getSource() {
		return source;
	}

	@JsonProperty("source")
	public void setSource(String source) {
		this.source = source;
	}

	@JsonProperty("inReplyToUserId")
	public Long getInReplyToUserId() {
		return inReplyToUserId;
	}

	@JsonProperty("inReplyToUserId")
	public void setInReplyToUserId(Long inReplyToUserId) {
		this.inReplyToUserId = inReplyToUserId;
	}

	@JsonProperty("favoriteCount")
	public Integer getFavoriteCount() {
		return favoriteCount;
	}

	@JsonProperty("favoriteCount")
	public void setFavoriteCount(Integer favoriteCount) {
		this.favoriteCount = favoriteCount;
	}

	@JsonProperty("inReplyToScreenName")
	public Object getInReplyToScreenName() {
		return inReplyToScreenName;
	}

	@JsonProperty("inReplyToScreenName")
	public void setInReplyToScreenName(Object inReplyToScreenName) {
		this.inReplyToScreenName = inReplyToScreenName;
	}

	@JsonProperty("place")
	public Object getPlace() {
		return place;
	}

	@JsonProperty("place")
	public void setPlace(Object place) {
		this.place = place;
	}

	@JsonProperty("retweetCount")
	public Integer getRetweetCount() {
		return retweetCount;
	}

	@JsonProperty("retweetCount")
	public void setRetweetCount(Integer retweetCount) {
		this.retweetCount = retweetCount;
	}

	@JsonProperty("lang")
	public String getLang() {
		return lang;
	}

	@JsonProperty("lang")
	public void setLang(String lang) {
		this.lang = lang;
	}

	@JsonProperty("retweetedStatus")
	public TwitterStatusModel getRetweetedStatus() {
		return retweetedStatus;
	}

	@JsonProperty("retweetedStatus")
	public void setRetweetedStatus(TwitterStatusModel retweetedStatus) {
		this.retweetedStatus = retweetedStatus;
	}

	@JsonProperty("userMentionEntities")
	public List<Object> getUserMentionEntities() {
		return userMentionEntities;
	}

	@JsonProperty("userMentionEntities")
	public void setUserMentionEntities(List<Object> userMentionEntities) {
		this.userMentionEntities = userMentionEntities;
	}

	@JsonProperty("currentUserRetweetId")
	public Long getCurrentUserRetweetId() {
		return currentUserRetweetId;
	}

	@JsonProperty("currentUserRetweetId")
	public void setCurrentUserRetweetId(Long currentUserRetweetId) {
		this.currentUserRetweetId = currentUserRetweetId;
	}

	@JsonProperty("user")
	public User getUser() {
		return user;
	}

	@JsonProperty("user")
	public void setUser(User user) {
		this.user = user;
	}

	@JsonProperty("favorited")
	public Boolean getFavorited() {
		return favorited;
	}

	@JsonProperty("favorited")
	public void setFavorited(Boolean favorited) {
		this.favorited = favorited;
	}

	@JsonProperty("retweetedByMe")
	public Boolean getRetweetedByMe() {
		return retweetedByMe;
	}

	@JsonProperty("retweetedByMe")
	public void setRetweetedByMe(Boolean retweetedByMe) {
		this.retweetedByMe = retweetedByMe;
	}
	

}
