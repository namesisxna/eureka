package com.self.atlas.mail.notification.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;

public class MailNotificationModel implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -2321930178060802304L;
	private List<String> to;
	private String from;
	private List<String> cc;
	private List<String> bcc;
	private String subject;
	private String body;
	private List<String> tableHeader;
	private List<List<String>> tableData;
	
	private HashMap<String, String> model;
	public List<String> getTo() {
		return to;
	}
	public void setTo(List<String> to) {
		this.to = to;
	}
	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public List<String> getCc() {
		return cc;
	}
	public void setCc(List<String> cc) {
		this.cc = cc;
	}
	public List<String> getBcc() {
		return bcc;
	}
	public void setBcc(List<String> bcc) {
		this.bcc = bcc;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getBody() {
		return body;
	}
	public void setBody(String body) {
		this.body = body;
	}
	public HashMap<String, String> getModel() {
		return model;
	}
	public void setModel(HashMap<String, String> model) {
		this.model = model;
	}
	public List<String> getTableHeader() {
		return tableHeader;
	}
	public void setTableHeader(List<String> tableHeader) {
		this.tableHeader = tableHeader;
	}
	public List<List<String>> getTableData() {
		return tableData;
	}
	public void setTableData(List<List<String>> tableData) {
		this.tableData = tableData;
	}
	

}
