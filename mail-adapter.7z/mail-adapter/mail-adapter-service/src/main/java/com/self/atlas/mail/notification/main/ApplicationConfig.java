package com.self.atlas.mail.notification.main;

import java.nio.charset.StandardCharsets;

//import javax.servlet.MultipartConfigElement;

import org.apache.camel.CamelContext;
import org.apache.camel.component.servlet.CamelHttpTransportServlet;
import org.apache.camel.spring.SpringCamelContext;
import org.apache.camel.spring.boot.CamelContextConfiguration;
import org.jasypt.encryption.StringEncryptor;
import org.jasypt.encryption.pbe.PooledPBEStringEncryptor;
import org.jasypt.encryption.pbe.config.SimpleStringPBEConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.MultipartConfigFactory;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.thymeleaf.spring4.SpringTemplateEngine;
import org.thymeleaf.spring4.templateresolver.SpringResourceTemplateResolver;
import org.thymeleaf.templatemode.StandardTemplateModeHandlers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

@Configuration

public class ApplicationConfig {
	@Autowired
	private ObjectMapper objectMapper;
	@Value("${mail.notification.template.dir}")
	private String templateDir;

	@Bean
	CamelContextConfiguration contextConfiguration(@Value("${service.name}") String name) {
		return new CamelContextConfiguration() {

			@Override
			public void beforeApplicationStart(CamelContext cc) {
				SpringCamelContext springCamelContext = (SpringCamelContext) cc;
				springCamelContext.setName(name);
				objectMapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
			}

			@Override
			public void afterApplicationStart(CamelContext cc) {

			}
		};
	}

	@Bean
	public ServletRegistrationBean camelServlet(@Value("${service.name}") String serviceName,
			@Value("${service.version}") String serviceVersion) {
		ServletRegistrationBean servlet = new ServletRegistrationBean();
		servlet.setServlet(new CamelHttpTransportServlet());
		servlet.addUrlMappings(String.format("/%s/%s/*", serviceName, serviceVersion));
		servlet.setName("CamelServlet");
		return servlet;
	}

//	@Bean
//	public ServletRegistrationBean servletRegistrationBean() {
//		return new ServletRegistrationBean(new HystrixMetricsStreamServlet(), "/hystrix.stream");
//	}
	
	@Bean
    public SpringTemplateEngine springTemplateEngine() {
        SpringTemplateEngine templateEngine = new SpringTemplateEngine();
        templateEngine.addTemplateResolver(htmlTemplateResolver());
        return templateEngine;
    }

    @Bean
    public SpringResourceTemplateResolver htmlTemplateResolver(){
        SpringResourceTemplateResolver emailTemplateResolver = new SpringResourceTemplateResolver();
        //emailTemplateResolver.setPrefix("classpath:/templates/");
        emailTemplateResolver.setPrefix("file:///"+templateDir);
        emailTemplateResolver.setSuffix(".html");
        emailTemplateResolver.setTemplateMode(StandardTemplateModeHandlers.HTML5.getTemplateModeName());
        emailTemplateResolver.setCharacterEncoding(StandardCharsets.UTF_8.name());
       
        return emailTemplateResolver;
    }

//	@Bean
//	public ConnectionFactory activemqConnectionFactory() {
//		RedeliveryPolicy rp = new RedeliveryPolicy();
//		rp.setMaximumRedeliveries(RedeliveryPolicy.NO_MAXIMUM_REDELIVERIES);
//
//		ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory();
//		connectionFactory.setBrokerURL("tcp://localhost:61616?jms.prefetchPolicy.all=1");
//		connectionFactory.setUserName("admin");
//		connectionFactory.setPassword("admin");
//		connectionFactory.setRedeliveryPolicy(rp);
//
//		PooledConnectionFactory pcf = new PooledConnectionFactory(connectionFactory);
//		return pcf;
//	}

//	@Bean
//	public JmsTransactionManager jmsTransactionManager(ConnectionFactory connectionFactory) {
//		return new JmsTransactionManager(connectionFactory);
//	}

	/**
	 * @return activemq camel component
	 */
//	@Bean
//	public ActiveMQComponent activemq(ConnectionFactory connectionFactory) {
//		ActiveMQComponent activeMqComponent = new ActiveMQComponent();
//		activeMqComponent.setTestConnectionOnStartup(true);
//		activeMqComponent.setTransacted(true);
//		activeMqComponent.setConnectionFactory(connectionFactory);
//		activeMqComponent.setTransactionManager(jmsTransactionManager(connectionFactory));
//
//		return activeMqComponent;
//	}

	@Bean(name = "encryptorBean")
	public StringEncryptor stringEncryptor() {
		PooledPBEStringEncryptor encryptor = new PooledPBEStringEncryptor();
		SimpleStringPBEConfig config = new SimpleStringPBEConfig();
		config.setPassword("password");
		config.setAlgorithm("PBEWithMD5AndDES");
		config.setKeyObtentionIterations("1000");
		config.setPoolSize("1");
		config.setProviderName("SunJCE");
		config.setSaltGeneratorClassName("org.jasypt.salt.RandomSaltGenerator");
		config.setStringOutputType("base64");
		encryptor.setConfig(config);
		return encryptor;
	}

//	@Bean
//	public MultipartConfigElement multipartConfigElement() {
//		MultipartConfigFactory factory = new MultipartConfigFactory();
//		factory.setMaxFileSize("10MB");
//		factory.setMaxRequestSize("10MB");
//		return factory.createMultipartConfig();
//	}

}
