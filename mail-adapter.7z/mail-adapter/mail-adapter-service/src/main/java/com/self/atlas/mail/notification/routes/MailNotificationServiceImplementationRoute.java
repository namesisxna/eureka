package com.self.atlas.mail.notification.routes;

import org.apache.camel.Exchange;
import org.apache.camel.ExchangePattern;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.self.atlas.mail.notification.beans.MailNotificationHelperBean;
//import com.cognizant.cosmos.service.discovery.common.ServiceCallConfiguration;
import com.self.atlas.mail.notification.model.MailNotificationModel;
import com.self.atlas.mail.notification.utils.RecoveryAggregator;

@Component
public class MailNotificationServiceImplementationRoute extends RouteBuilder {

//	@Autowired
//	private ServiceCallConfiguration serviceCallConfiguration;
	@Value("${mail.notification.recovery.delay}")
	private String recoveryDelay;
	
	@Value("${recipient.threshold}")
	private String threshold;
	

	@Override
	public void configure() throws Exception {
		//AggregationStrategy aggregationStrategy = new ExampleAggregationStrategy();
		//errorHandler(deadLetterChannel("activemq:queue:mail-notification-error-queue").maximumRedeliveries(3).redeliveryDelay(5000));
		onException(Exception.class)
		.log(LoggingLevel.ERROR, "Exceptopn Occured(Inside onException block)!!!!")
		.to("direct:exp")
		.handled(true);
		
		from("direct:exp")
		.bean(MailNotificationHelperBean.class,"getExceptionType")
		.choice()
		.when(header("X-MAIL-RECOVERY").isEqualTo(true))
			.to(ExchangePattern.InOnly,"activemq:queue:mail-notification-recovery-queue")
			.log(LoggingLevel.WARN, "As SMTP Server is unable to process,sending mail in recovery queue!")
			.setHeader(Exchange.HTTP_RESPONSE_CODE,constant(202))
			.setBody(constant("email sent to recovery queue "))
		.otherwise()
		.marshal().json(JsonLibrary.Jackson)
			.to(ExchangePattern.InOnly,"activemq:queue:mail-notification-error-queue")
			.setHeader(Exchange.HTTP_RESPONSE_CODE,constant(500))
			.log(LoggingLevel.ERROR, "Unable to process  mail!")
		.end();
		
		
//		onException(SMTPConnectionException.class)
//		.to(ExchangePattern.InOnly,"activemq:queue:mail-notification-recovery-queue")
//		.log(LoggingLevel.ERROR,"${exception.message}")
//        .setBody(constant(null))
//        .setHeader(Exchange.HTTP_RESPONSE_CODE, constant("202"))
//		.handled(true);
//		
//		onException(Exception.class)
//		//.bean(MailNotificationHelperBean.class,"getExceptionType")
//		.to(ExchangePattern.InOnly,"activemq:queue:mail-notification-error-queue")
//		.log(LoggingLevel.ERROR, "Unable to process  mail!")
//		.handled(true);

	 //   getContext().setServiceCallConfiguration(serviceCallConfiguration.registerConfiguration());
	    //from("direct:test")
	    //.bean(MailNotificationHelperBean.class,"setHeaders")
		 //.to("activemq:queue:testQueue?disableReplyTo=true")
		//.to("smtp://smtp.gmail.com:25?password=""&username=sumitdatta2015&mail.smtp.starttls.enable=true&mail.smtp.socketFactory.class=javax.net.ssl.SSLSocketFactory")
	    //.recipientList(simple("smtp://${property.X-SMTP-SERVER}:${property.X-SMTP-SERVER-PORT}?${property.X-SMTP-QUERY}"))
	    //.bean(MailNotificationHelperBean.class,"printHeaders");
	    
	   // from("file://"+templateDir).to("file")
	    
	    from("direct:postNotification")
	    .choice()
	    .when(simple("${body.to.size} <= "+threshold))
	    	.log(LoggingLevel.INFO, "List size is less than 50")	
	    	.bean(MailNotificationHelperBean.class,"sendMail")
	    	.to("direct:processSMTP")
	    .otherwise()
	    //.doTry()
	    	.bean(MailNotificationHelperBean.class,"processRecipientListAsChunk")
	    	.split(body())
	    	.parallelProcessing()
	    	.log("--------creating chunk of recipient list as the list contain higher values then threshold---------")
	    	.doTry()
	    	.bean(MailNotificationHelperBean.class,"sendMail")
	    	.to("direct:processSMTP")
	    	.doCatch(Exception.class)
	    	.to("direct:exp");
//	    	.aggregate(new RecoveryAggregator())
//	    	.
	    
	    from("direct:postBatchNotification")
	    .split(body(),new RecoveryAggregator())
	    .parallelProcessing()
	    .bean(MailNotificationHelperBean.class,"sendMail")
	    .recipientList(simple("smtp://${property.X-SMTP-SERVER}:${property.X-SMTP-SERVER-PORT}?${property.X-SMTP-QUERY}"))
	    //.bean(MailNotificationHelperBean.class,"printHeaders")
	    //.bean(MailNotificationHelperBean.class,"populateMailResponse")
	    .end()
	    .setHeader(Exchange.HTTP_RESPONSE_CODE,constant(201))
	    .setBody(constant("email sent successfully "));
	    
	    from("direct:processSMTP")
	    .recipientList(simple("smtp://${property.X-SMTP-SERVER}:${property.X-SMTP-SERVER-PORT}?${property.X-SMTP-QUERY}"))
	    .setHeader(Exchange.HTTP_RESPONSE_CODE,constant(201))
	    .setBody(constant("email sent successfully "));
	    
	    
	    
	   // from("direct:sendNotificationOnQueueEvent").log("xsds");
	    //.recipientList(simple("activemq:queue:${header.queueId}?disableReplyTo=true"));
	    
	   // from("activemq:queue:notification-queue?disableReplyTo=true").to("direct:A");
	    //from("direct:A").log("${body}");
	    
	    //from("activemq:queue:notification-queue?disableReplyTo=true").to("seda:A");
	    //from("activemq:test?disableReplyTo=true").log("${body}");
//	    from("file://C:/notification-directory?fileName=recipientlist.csv&noop=true").startupOrder(2).unmarshal()
//	    .csv().bean(CSVProcessor.class,"processData").to("direct:B");

    	//from("file://D:/notification-directory?fileName=mail.txt&noop=true").bean(CSVProcessor.class,"populateBody").to("direct:B");
//    	from("activemq:queue:notification-queue")
//    	.enrich("activemq:queue:notification-address-queue",aggregationStrategy);
	    
	    
	    //from("direct:B").to("activemq:queue:notification-address?disableReplyTo=true");
    	
//    	from("file://C:/notification-directory?fileName=recipientlist.csv&noop=true").unmarshal().csv()
//    	.bean(CSVProcessor.class,"processData").to("activemq:queue:notification-address-queue?deliveryPersistent=true");
    	
    	from("activemq:queue:mail-notification-queue").unmarshal().json(JsonLibrary.Jackson, MailNotificationModel.class)
        .bean(MailNotificationHelperBean.class,"sendMailOnQueueEvent")
        .recipientList(simple("smtp://${property.X-SMTP-SERVER}:${property.X-SMTP-SERVER-PORT}?${property.X-SMTP-QUERY}"))
        .setHeader(Exchange.HTTP_RESPONSE_CODE,constant(201))
        .setBody(constant("email sent successfully "));
    	
    	//from("timer://mail-tigger?fixedRate=true&period=20000")
    	from("activemq:queue:mail-notification-recovery-queue").delay(Integer.valueOf(recoveryDelay))
    	.bean(MailNotificationHelperBean.class,"populateRecoveryQueue")
    	.recipientList(simple("smtp://${property.X-SMTP-SERVER}:${property.X-SMTP-SERVER-PORT}?${property.X-SMTP-QUERY}"))
    	.setHeader(Exchange.HTTP_RESPONSE_CODE,constant(201))
        .setBody(constant("email sent successfully "));
	}
	
	
	
}
