package com.self.atlas.mail.notification.utils;

import org.apache.camel.Exchange;
import org.apache.camel.processor.aggregate.AggregationStrategy;

public class RecoveryAggregator implements AggregationStrategy{

	@Override
	public Exchange aggregate(Exchange oldExchange, Exchange newExchange) {
		System.out.println("$$$$$$$$$$$$$$$$$inside aggregate");
		
		
		return null;
	}

}
