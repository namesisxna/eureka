package com.self.atlas.mail.notification.utils;

public interface IConstants {
	interface SMTP_PROVIDER {
		String GOOGLE="GOOGLE";
		String CTS="CTS";
				
	}
	
}
