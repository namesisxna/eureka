package com.self.atlas.mail.notification.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "com.cognizant.cosmos,com.cognizant.centurion")

public class Application {

    public static void main(String[] args) {
	SpringApplication.run(Application.class, args);
    }

}
