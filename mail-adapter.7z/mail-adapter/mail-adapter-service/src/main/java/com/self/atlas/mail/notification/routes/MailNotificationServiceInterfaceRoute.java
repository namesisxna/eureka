package com.self.atlas.mail.notification.routes;
import static org.apache.camel.model.rest.RestParamType.path;
import static org.apache.camel.model.rest.RestParamType.query;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.rest.RestBindingMode;
import org.springframework.stereotype.Component;

import com.self.atlas.mail.notification.model.MailNotificationModel;



@Component
public class MailNotificationServiceInterfaceRoute extends RouteBuilder {

    @Override
    public void configure() throws Exception {
	
	restConfiguration()
		.component("{{server.component}}")
		.host("{{server.host}}").port("{{server.port}}")
		.bindingMode(RestBindingMode.json)
		.dataFormatProperty("prettyPrint", "true")
		.contextPath("/{{service.name}}/{{service.version}}")
		.apiContextPath("/")
		.apiProperty("api.title", "{{api.title}}")
		.apiProperty("api.version", "{{api.version}}")
		.apiProperty("apiContextIdListing", "{{apiContextIdListing}}")
		.apiProperty("apiContextIdPattern", "{{apiContextIdPattern}}")
		.apiProperty("api.description", "{{api.description}}")
		.apiProperty("api.termsOfService", "{{api.termsOfService}}")
		.apiProperty("api.contact.name", "{{api.contact.name}}")
		.apiProperty("api.contact.email", "{{api.contact.email}}")
		.apiProperty("api.contact.url", "{{api.contact.url}}")
		.apiProperty("api.license.name", "{{api.license.name}}")
		.apiProperty("api.license.url", "{{api.license.url}}");
	
	rest()
//   	       .get("/test")
//	        		.id("test")
//	        		.description("test Endpoint")
//	        		.to("direct:test")
	        
	       .post("/postNotification")
	        		.id("postNotification")
	        		.description("sendNotification")
	        		.type(MailNotificationModel.class)
	        		.outType(String.class)
	        		.to("direct:postNotification")
	       .post("/postBatchNotification")
	        		.id("postBatchNotification")
	        		.description("sendNotification")
	        		.type(MailNotificationModel[].class)
	        		.outType(String.class)
	        		.to("direct:postBatchNotification")
//	        .get("/sendNotificationOnQueueEvent/{queueId}")
//	        		.id("sendNotificationOnQueueEvent")
//	        		.description("sendNotificationOnQueueEvent")
//	        		.param().name("queueId").type(path).description("queueId").dataType("string").endParam()
//	        		.outType(String.class)
//	        		.to("direct:sendNotificationOnQueueEvent")
	        		
	         .get("/health")
	        		.id("health")
	        		.description("Health Check Endpoint")
	        		.outType(String.class)
	        		.to("direct:health");
	
    }
}