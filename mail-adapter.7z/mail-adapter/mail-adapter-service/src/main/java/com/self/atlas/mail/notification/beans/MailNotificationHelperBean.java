package com.self.atlas.mail.notification.beans;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;

import org.apache.camel.Exchange;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring4.SpringTemplateEngine;

import com.self.atlas.mail.notification.model.MailNotificationModel;
import com.self.atlas.mail.notification.utils.IConstants;

@Component
public class MailNotificationHelperBean {
	private static final Logger LOG = LoggerFactory.getLogger(MailNotificationHelperBean.class);
	@Value("${mail.notification.server}")
	private String mailServer;
	@Value("${mail.notification.server.port}")
	private String mailServerPort;
	@Value("${mail.notification.server.username}")
	private String userName;
	@Value("${mail.notification.server.password}")
	private String password;
	@Value("${SMTP.provider}")
	private String smtpProvider;
	@Value("${tamper.to.mailId}")
	private String tamperToMail;
	@Value("${tamper.cc.mailId}")
	private String tamperCCMail;
	@Value("${tamper.bcc.mailId}")
	private String tamperBCCMail;
	
	@Value("${recipient.threshold}")
	private String threshold;

	@Autowired
	private SpringTemplateEngine templateEngine;

	public void sendMail(Exchange exchange) {
		LOG.info("Entered MailNotificationHelperBean#sendMail");
		Map<String, Object> headers = exchange.getIn().getHeaders();
		exchange.setProperty("X-SMTP-SERVER", mailServer);
		exchange.setProperty("X-SMTP-SERVER-PORT", mailServerPort);
		exchange.setProperty("X-SMTP-QUERY", constructSMTPQueryvalue(exchange));
		MailNotificationModel mailNotification = exchange.getIn().getBody(MailNotificationModel.class);
		if (mailNotification == null) {
			throw new RuntimeException("Missing request body!!!");
		}
		if (mailNotification.getTo() == null) {
			throw new RuntimeException("Missing recipient mailId!!!");
		}
		headers.put("From", mailNotification.getFrom());
		
		HashSet<String> toSet = new HashSet<>(mailNotification.getTo());
		List<String> uniqueToList = new ArrayList<>(toSet);
		headers.put("To", constructRecipientList(uniqueToList));
		
		if(StringUtils.isNotEmpty(mailNotification.getSubject()))
		headers.put("Subject", mailNotification.getSubject());
		
		if(mailNotification.getCc()!=null && mailNotification.getCc().size()>0)
		{
		HashSet<String> ccSet = new HashSet<>(mailNotification.getCc());
		List<String> uniqueCCList = new ArrayList<>(ccSet);
		headers.put("Cc", constructCCList(uniqueCCList));
		}
		if(mailNotification.getBcc()!=null && mailNotification.getBcc().size()>0)
		{
		HashSet<String> bccSet = new HashSet<>(mailNotification.getBcc());
		List<String> uniqueBCCList = new ArrayList<>(bccSet);
		headers.put("Bcc", constructBCCList(uniqueBCCList));
		}
		
		headers.put("contentType", "text/html");
		// exchange.getIn().setBody(mailNotification.getBody(),String.class);
		// exchange.getIn().setBody(constructTemplate(mailNotification.getBody()),String.class);
		exchange.getIn().setBody(constructTemplate(mailNotification), String.class);
		// System.out.println(exchange.getIn().getBody(String.class));
		LOG.info("Exited MailNotificationHelperBean#sendMail");
	}

	public String constructSMTPQueryvalue(Exchange exchange) {
		StringBuffer queryBuilder = new StringBuffer();
		switch (smtpProvider.toUpperCase()) {
		case IConstants.SMTP_PROVIDER.CTS:
			queryBuilder.append("username=").append(userName).append("&").append("password=").append(password).append(
					"&mail.smtp.starttls.enable=true&mail.smtp.socketFactory.class=javax.net.ssl.SSLSocketFactory&mail.smtp.auth=true");
			break;

		default:
			break;
		}
		return queryBuilder.toString();
	}

	public String constructRecipientList(List<String> recipientList) {
		if(tamperToMail!=null && Boolean.valueOf(tamperToMail)==true){
			List<String> tamperList = createTamperMaillist(recipientList.stream().filter(value -> value != null).collect(Collectors.toList()));
			return String.join("; ", tamperList);
		}
		return String.join("; ", recipientList.stream().filter(value -> value != null).collect(Collectors.toList()));
	}

	public String constructCCList(List<String> ccList) {
		if(tamperCCMail!=null && Boolean.valueOf(tamperCCMail)==true){
			List<String> tamperList = createTamperMaillist(ccList.stream().filter(value -> value != null).collect(Collectors.toList()));
			return String.join("; ", tamperList);
		}
		return String.join("; ", ccList.stream().filter(value -> value != null).collect(Collectors.toList()));

	}

	public String constructBCCList(List<String> bccList) {
		if(tamperBCCMail!=null && Boolean.valueOf(tamperBCCMail)==true){
			List<String> tamperList = createTamperMaillist(bccList.stream().filter(value -> value != null).collect(Collectors.toList()));
			return String.join("; ", tamperList);
		}
		return String.join("; ", bccList.stream().filter(value -> value != null).collect(Collectors.toList()));
	}

	public static boolean isValidEmailAddress(String email) {
		boolean result = true;
		try {
			InternetAddress emailAddr = new InternetAddress(email);
			emailAddr.validate();
		} catch (AddressException ex) {
			result = false;
		}
		return result;
	}

	public void sendMailOnQueueEvent(Exchange exchange) {
		LOG.info("Entered MailNotificationHelperBean#sendMailOnQueueEvent");
		sendMail(exchange);
		LOG.info("Exited MailNotificationHelperBean#sendMailOnQueueEvent");
	}

	public String constructTemplate(MailNotificationModel notificationModel) {

		HashMap<String, String> emailModel = notificationModel.getModel();
		Map<String, Object> model = new HashMap<String, Object>();
		// model.put("body", emailBody);
		//String para1 = emailModel.get("para1");
		// para1.split("")
		// model.put("para1", emailModel.get("para1"));
		//Map<String, Object> constructParaTemplate = constructParaTemplate(model, notificationModel);
		model.put("para1", emailModel.get("para1"));
		model.put("para2", emailModel.get("para2"));
		model.put("url", emailModel.get("url"));
		model.put("name", emailModel.get("name"));
		model.put("dpurl", "https://contentops.cognizant.com/static/emailer-footer-Image.png");
		Map<String, Object> constructTableTemplate = constructTableTemplate(model, notificationModel);
		Context context = new Context();
		context.setVariables(constructTableTemplate);

		String html = templateEngine.process("centurion-template", context);
		return html;

	}

	public void getExceptionType(Exchange exchange) {
		Map<String, Object> headers = exchange.getIn().getHeaders();
		Exception cause = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Exception.class);
		if (cause != null) {
			// LOG.error("------------" +
			// cause.getMessage().split(",")[2].split(":")[1]);
			if (cause.getClass().getCanonicalName().equals("javax.mail.MessagingException")
					&& cause.getMessage().split(",")[2].split(":")[1].trim().equals("421")) {

				headers.put("X-MAIL-RECOVERY", true);
				// throw new SMTPConnectionException();
			}
			LOG.error("Error has occurred: ", cause);
		}
		headers.put("X-ExceptionType", cause.getClass().getCanonicalName());
	}

	public void populateRecoveryQueue(Exchange exchange) {
		LOG.info("Entered MailNotificationHelperBean#populateRecoveryQueue");
		exchange.setProperty("X-SMTP-SERVER", mailServer);
		exchange.setProperty("X-SMTP-SERVER-PORT", mailServerPort);
		exchange.setProperty("X-SMTP-QUERY", constructSMTPQueryvalue(exchange));
		LOG.info("Exited MailNotificationHelperBean#populateRecoveryQueue");
		LOG.info("Trying to recover failed mail..");

	}

	// To be implemented if needed for batch mail triggering from csv
	// @Value("${mail-notification-recipientlist}")
	// private String recipientlistFilePath;
	// public MailNotificationModel constructMailNotificationModelFromCSV() {
	// List<String> to = new ArrayList<String>();
	// List<String> cc = new ArrayList<String>();
	// List<String> bcc = new ArrayList<String>();
	// MailNotificationModel mailNotificationModel = new
	// MailNotificationModel();
	// try (Stream<String> stream =
	// Files.lines(Paths.get(recipientlistFilePath))) {
	// stream.skip(1).forEach(item -> {
	// String[] columnValue = item.split(",");
	// List<String> asList = Arrays.asList(columnValue);
	// to.add(asList.get(0));
	// cc.add(asList.get(1));
	// bcc.add(asList.get(2));
	// mailNotificationModel.setTo(to);
	// mailNotificationModel.setCc(cc);
	// mailNotificationModel.setBcc(bcc);
	// });
	//
	// } catch (IOException e) {
	// e.printStackTrace();
	// }
	// return mailNotificationModel;
	// }

	// public void printHeaders(Exchange exchange) {
	// LOG.info("Entered MailNotificationHelperBean#setHeaders");
	// Map<String, Object> headers = exchange.getIn().getHeaders();
	// for (Entry<String, Object> headersValue : headers.entrySet()) {
	// System.out.println("key:" + headersValue.getKey() + "value: " +
	// headersValue.getValue());
	// }
	// }

	// public void setHeaders(Exchange exchange) {
	// LOG.info("Entered MailNotificationHelperBean#setHeaders");
	// Map<String, Object> headers = exchange.getIn().getHeaders();
	// headers.put("To", "sumitdatta2018@gmail.com");
	// headers.put("Subject", "demo");
	// exchange.setProperty("X-SMTP-SERVER", mailServer);
	// exchange.setProperty("X-SMTP-SERVER-PORT", mailServerPort);
	// exchange.setProperty("X-SMTP-QUERY", constructSMTPQueryvalue(exchange));
	// exchange.getIn().setBody("test");
	// }

	public Map<String, Object> constructTableTemplate(Map<String, Object> model,
			MailNotificationModel notificationModel) {
		if (notificationModel.getTableHeader() != null) {
			List<String> tableHeaders = notificationModel.getTableHeader();
			model.put("tableHeaders", tableHeaders);
		}
		if (notificationModel.getTableData() != null) {
			List<List<String>> tableData = notificationModel.getTableData();
			model.put("tableData", tableData);
		}
		return model;
	}

	public Map<String, Object> constructParaTemplate(Map<String, Object> model,
			MailNotificationModel notificationModel) {
		String para1 =notificationModel.getModel().get("para1");
		
		String[] split = para1.split("%");
		if(split.length==3){
			System.out.println(split[0]);
			model.put("part1", split[0]);
			String hyperlinkpart = split[1];
			System.out.println(hyperlinkpart);
			String[] split2 = hyperlinkpart.split("!");
			String hyperlinkKey = split2[0];
			model.put("link", hyperlinkKey);
			System.out.println(hyperlinkKey);
			String hyperlinkValue = split2[1];
			System.out.println(hyperlinkValue);
			model.put("url", hyperlinkValue);
			System.out.println(split[2]);
			model.put("part2", split[2]);
		}
		
		
				return model;
		
	}
	
	public List<String> createTamperMaillist(List<String> actualList){
		
		List<String> tamperList = new ArrayList<String>();
		actualList.forEach((email)->{
			if(email.contains("@cognizant")){
				email = email.replace("@cognizant", "@cognizant1");
				tamperList.add(email);
			}
			else if(email.contains("@spi-global")){
				email= email.replace("@spi-global", "@spi-global1");
				tamperList.add(email);
			}
			else if(email.contains("@gmail")){
				email = email.replace("@gmail", "@gmail1");
				tamperList.add(email);
			}
			else if(email.contains("@pearson")){
				email = email.replace("@pearson", "@pearson1");
				tamperList.add(email);
			}
			else {
				tamperList.add(email);
			}
		});
		return tamperList;
		
	}
	
	public static <T> Stream<List<T>> ofSubLists(List<T> source, int length) {
        if (length <= 0)
            throw new IllegalArgumentException("length = " + length);
        int size = source.size();
        if (size <= 0)
            return Stream.empty();
        int fullChunks = (size - 1) / length;
        return IntStream.range(0, fullChunks + 1).mapToObj(
            n -> source.subList(n * length, n == fullChunks ? size : (n + 1) * length));
    }
	public List<MailNotificationModel> processRecipientListAsChunk(Exchange exchange) {
		LOG.info("Entered MailNotificationHelperBean#processChunkRecipient");
		Map<String, Object> headers = exchange.getIn().getHeaders();
		exchange.setProperty("X-SMTP-SERVER", mailServer);
		exchange.setProperty("X-SMTP-SERVER-PORT", mailServerPort);
		exchange.setProperty("X-SMTP-QUERY", constructSMTPQueryvalue(exchange));
		List<MailNotificationModel> mailNotificationModels = new ArrayList<>();
		MailNotificationModel originalMailNotification = exchange.getIn().getBody(MailNotificationModel.class);
		List<String> to = originalMailNotification.getTo();
		Stream<List<String>> ofSubLists = ofSubLists(to, Integer.valueOf(threshold));
		ofSubLists.forEach((chunkedTo) ->{
			MailNotificationModel mailNotificationModel = new MailNotificationModel();
			mailNotificationModel.setTo(chunkedTo);
			mailNotificationModel.setCc(originalMailNotification.getCc());
			mailNotificationModel.setBcc(originalMailNotification.getBcc());
			mailNotificationModel.setFrom(originalMailNotification.getFrom());
			mailNotificationModel.setSubject(originalMailNotification.getSubject());
			mailNotificationModel.setModel(originalMailNotification.getModel());
			mailNotificationModel.setTableHeader(originalMailNotification.getTableHeader());
			mailNotificationModel.setTableData(originalMailNotification.getTableData());
			mailNotificationModels.add(mailNotificationModel);
		});
		return mailNotificationModels;
		
	}
	public static void main(String[] args) {
		String para1 = "Project ID %P1234567890!https://google.com/#%, Lorem ispem has been assigned to you by John Doe (Content Writer). Please note Planned Start Date of the R Assessment stage is 26 Feb 2018.";
		String[] split = para1.split("%");
		System.out.println(split[0]);
		String hyperlinkpart = split[1];
		System.out.println(hyperlinkpart);
		String[] split2 = hyperlinkpart.split("!");
		String hyperlinkKey = split2[0];
		System.out.println(hyperlinkKey);
		String hyperlinkValue = split2[1];
		System.out.println(hyperlinkValue);
		System.out.println(split[2]);
	}

}